create function inventory_held_by_customer(p_inventory_id integer) returns integer
    language plpgsql
as
$$
declare
    v_customer_id integer;
begin
  select customer_id into v_customer_id
  from rental
  where return_date is null
  and inventory_id = p_inventory_id;
  return v_customer_id;
end $$;

alter function inventory_held_by_customer(integer) owner to postgres;

