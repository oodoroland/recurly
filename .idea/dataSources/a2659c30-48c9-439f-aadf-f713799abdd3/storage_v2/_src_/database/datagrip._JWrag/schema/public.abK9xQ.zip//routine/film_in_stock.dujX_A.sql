create function film_in_stock(p_film_id integer, p_store_id integer, OUT p_film_count integer) returns SETOF integer
    language sql
as
$$
     select inventory_id
     from inventory
     where film_id = $1
     and store_id = $2
     and inventory_in_stock(inventory_id);
$$;

alter function film_in_stock(integer, integer, out integer) owner to postgres;

