create function inventory_in_stock(p_inventory_id integer) returns boolean
    language plpgsql
as
$$
declare
    v_rentals integer;
    v_out     integer;
begin
    -- an item is in-stock if there are either no rows in the rental table
    -- for the item or all rows have return_date populated

    select count(*) into v_rentals
    from rental
    where inventory_id = p_inventory_id;

    if v_rentals = 0 then
      return true;
    end if;

    select count(rental_id) into v_out
    from inventory left join rental using(inventory_id)
    where inventory.inventory_id = p_inventory_id
    and rental.return_date is null;

    if v_out > 0 then
      return false;
    else
      return true;
    end if;
end $$;

alter function inventory_in_stock(integer) owner to postgres;

