create function _group_concat(text, text) returns text
    immutable
    language sql
as
$$
select case
  when $2 is null then $1
  when $1 is null then $2
  else $1 || ', ' || $2
end
$$;

alter function _group_concat(text, text) owner to postgres;

