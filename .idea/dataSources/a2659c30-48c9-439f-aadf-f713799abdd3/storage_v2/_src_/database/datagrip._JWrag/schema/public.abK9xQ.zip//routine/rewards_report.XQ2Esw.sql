create function rewards_report(min_monthly_purchases integer, min_dollar_amount_purchased numeric) returns SETOF customer
    security definer
    language plpgsql
as
$$
declare
    last_month_start date;
    last_month_end date;
rr record;
tmpsql text;
begin

    /* some sanity checks... */
    if min_monthly_purchases = 0 then
        raise exception 'minimum monthly purchases parameter must be > 0';
    end if;
    if min_dollar_amount_purchased = 0.00 then
        raise exception 'minimum monthly dollar amount purchased parameter must be > $0.00';
    end if;

    last_month_start := current_date - '3 month'::interval;
    last_month_start := to_date((extract(year from last_month_start) || '-' || extract(month from last_month_start) || '-01'),'yyyy-mm-dd');
    last_month_end := last_day(last_month_start);

    /*
    create a temporary storage area for customer ids.
    */
    create temporary table tmpcustomer (customer_id integer not null primary key);

    /*
    find all customers meeting the monthly purchase requirements
    */

    tmpsql := 'insert into tmpcustomer (customer_id)
        select p.customer_id
        from payment as p
        where date(p.payment_date) between '||quote_literal(last_month_start) ||' and '|| quote_literal(last_month_end) || '
        group by customer_id
        having sum(p.amount) > '|| min_dollar_amount_purchased || '
        and count(customer_id) > ' ||min_monthly_purchases ;

    execute tmpsql;

    /*
    output all customer information of matching rewardees.
    customize output as needed.
    */
    for rr in execute 'select c.* from tmpcustomer as t inner join customer as c on t.customer_id = c.customer_id' loop
        return next rr;
    end loop;

    /* clean up */
    tmpsql := 'drop table tmpcustomer';
    execute tmpsql;

return;
end
$$;

alter function rewards_report(integer, numeric) owner to postgres;

