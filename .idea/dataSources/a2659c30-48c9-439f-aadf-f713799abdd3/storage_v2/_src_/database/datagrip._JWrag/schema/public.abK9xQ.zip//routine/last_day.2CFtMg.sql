create function last_day(timestamp without time zone) returns date
    immutable
    strict
    language sql
as
$$
  select case
    when extract(month from $1) = 12 then
      (((extract(year from $1) + 1) operator(pg_catalog.||) '-01-01')::date - interval '1 day')::date
    else
      ((extract(year from $1) operator(pg_catalog.||) '-' operator(pg_catalog.||) (extract(month from $1) + 1) operator(pg_catalog.||) '-01')::date - interval '1 day')::date
    end
$$;

alter function last_day(timestamp) owner to postgres;

