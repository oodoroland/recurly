create function get_customer_balance(p_customer_id integer, p_effective_date timestamp without time zone) returns numeric
    language plpgsql
as
$$
       --#ok, we need to calculate the current balance given a customer_id and a date
       --#that we want the balance to be effective for. the balance is:
       --#   1) rental fees for all previous rentals
       --#   2) one dollar for every day the previous rentals are overdue
       --#   3) if a film is more than rental_duration * 2 overdue, charge the replacement_cost
       --#   4) subtract all payments made before the date specified
declare
    v_rentfees decimal(5,2); --#fees paid to rent the videos initially
    v_overfees integer;      --#late fees for prior rentals
    v_payments decimal(5,2); --#sum of payments made previously
begin
    select coalesce(sum(film.rental_rate),0) into v_rentfees
    from film, inventory, rental
    where film.film_id = inventory.film_id
      and inventory.inventory_id = rental.inventory_id
      and rental.rental_date <= p_effective_date
      and rental.customer_id = p_customer_id;

    select coalesce(sum(if((rental.return_date - rental.rental_date) > (film.rental_duration * '1 day'::interval),
        ((rental.return_date - rental.rental_date) - (film.rental_duration * '1 day'::interval)),0)),0) into v_overfees
    from rental, inventory, film
    where film.film_id = inventory.film_id
      and inventory.inventory_id = rental.inventory_id
      and rental.rental_date <= p_effective_date
      and rental.customer_id = p_customer_id;

    select coalesce(sum(payment.amount),0) into v_payments
    from payment
    where payment.payment_date <= p_effective_date
    and payment.customer_id = p_customer_id;

    return v_rentfees + v_overfees - v_payments;
end
$$;

alter function get_customer_balance(integer, timestamp) owner to postgres;

