create function prevent_password_change() returns event_trigger
    language plpgsql
as
$$
BEGIN
  IF current_user = 'datagrip_user' AND
     tg_tag = 'ALTER ROLE' THEN
    RAISE EXCEPTION 'You cannot change your own password';
  END IF;
END;
$$;

alter function prevent_password_change() owner to postgres;

