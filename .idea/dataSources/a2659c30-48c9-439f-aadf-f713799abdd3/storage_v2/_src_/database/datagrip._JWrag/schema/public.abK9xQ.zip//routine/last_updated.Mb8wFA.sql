create function last_updated() returns trigger
    language plpgsql
as
$$
begin
    new.last_update = current_timestamp;
    return new;
end $$;

alter function last_updated() owner to postgres;

